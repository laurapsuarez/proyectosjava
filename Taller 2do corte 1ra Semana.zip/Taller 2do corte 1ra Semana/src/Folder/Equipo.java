package Folder;

import javax.swing.JOptionPane;

class Equipo {
    String codigo;
    String nombre;
    String ciudad;
    int campeonatosGanados;

    public Equipo(String codigo, String nombre, String ciudad, int campeonatosGanados) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.campeonatosGanados = campeonatosGanados;
    }
}








    

