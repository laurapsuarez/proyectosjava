package Folder;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        
        Lista listaEquipos = new Lista();
        int opcion;

        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog("Menú:\n1. Ingresar un registro\n2. Mostrar lista enlazada\n3. Salir"));

                switch (opcion) {
                    case 1:
                        String codigo = "", nombre = "", ciudad = "";
                        int campeonatosGanados = 0;
                        boolean ingresoExitoso = false;
                        while (!ingresoExitoso) {
                            try {
                                codigo = JOptionPane.showInputDialog("Ingrese el código del equipo:");
                                nombre = JOptionPane.showInputDialog("Ingrese el nombre del equipo:");
                                ciudad = JOptionPane.showInputDialog("Ingrese la ciudad del equipo:");
                                while (true) {
                                    try {
                                        campeonatosGanados = Integer.parseInt(JOptionPane.showInputDialog("Ingrese los campeonatos ganados por el equipo:"));
                                        break; // Si se llega aquí, la entrada fue válida, salimos del bucle
                                    } catch (NumberFormatException e) {
                                        JOptionPane.showMessageDialog(null, "Error: Debe ingresar un número para los campeonatos ganados.");
                                    }
                                }
                                ingresoExitoso = true; // Si llegamos aquí, todos los datos son válidos
                            } catch (Exception e) {
                                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
                            }
                        }
                        Equipo equipo = new Equipo(codigo, nombre, ciudad, campeonatosGanados);
                        listaEquipos.insertar(equipo);
                        JOptionPane.showMessageDialog(null, "Equipo registrado correctamente.");
                        break;



                    case 2:
                        JOptionPane.showMessageDialog(null, listaEquipos.mostrar());
                        break;

                    case 3:
                        JOptionPane.showMessageDialog(null, "Saliendo del programa...");
                        break;

                    default:
                        JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Debe ingresar un número.");
                opcion = 0; // Reiniciar la opción para volver al menú
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
                opcion = 0; // Reiniciar la opción para volver al menú
            }
        } while (opcion != 3);
    }
     
    }
    

