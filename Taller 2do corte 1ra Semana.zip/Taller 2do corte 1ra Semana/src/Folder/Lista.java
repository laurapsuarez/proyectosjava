
package Folder;

class Lista {
    Nodo primero;

    public Lista() {
        this.primero = null;
    }

    public void insertar(Equipo equipo) {
        Nodo nuevo = new Nodo(equipo);
        if (primero == null) {
            primero = nuevo;
        } else {
            nuevo.siguiente = primero;
            primero = nuevo;
        }
    }

    public String mostrar() {
        StringBuilder tabla = new StringBuilder();
        tabla.append("<html><table border='1'><tr><th>Código</th><th>Nombre</th><th>Ciudad</th><th>Campeonatos Ganados</th></tr>");

        Nodo actual = primero;
        while (actual != null) {
            tabla.append("<tr><td>").append(actual.equipo.codigo).append("</td><td>")
                 .append(actual.equipo.nombre).append("</td><td>")
                 .append(actual.equipo.ciudad).append("</td><td>")
                 .append(actual.equipo.campeonatosGanados).append("</td></tr>");
            actual = actual.siguiente;
        }
        tabla.append("</table></html>");
        
        return tabla.toString();
    }
}
