
package Folder;

class Nodo {
    Equipo equipo;
    Nodo siguiente;

    public Nodo(Equipo equipo) {
        this.equipo = equipo;
        this.siguiente = null;
    }
}
